package com.amazon.main;

public class AppiumManager {
	public static String startAppium(String deviceName, String port, String nodeConfigJSONPath,  String seleniumGridServer) throws Exception
	{
	    String chromePort = Integer.toString(PortManager.getAvailablePort());
	    String bootstrapPort = Integer.toString(PortManager.getAvailablePort());

	    String command = "appium --address " + seleniumGridServer + " --session-override -p " + port +
	            " -U " + deviceName +
	            " --command-timeout 300" +
	            " --no-reset" +
	            " --chromedriver-port "+ chromePort +" -bp "+ bootstrapPort +
	            " --nodeconfig "+ nodeConfigJSONPath;
	    if(System.getProperty("os.name").split(" ")[0].toUpperCase().equals("WINDOWS"))
	    {
	        String toRun=command.replaceAll("/D:","D:");
	        ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
	        String path = classLoader.getResource("").getPath().toString() + "/" + deviceName + ".bat";
	        FileWriter file = new FileWriter(path);
	        file.write(toRun);
	        file.flush();
	        file.close();
	        Desktop.getDesktop().open(new File(path));
	    }
	    else
	    {
	        String output = Terminal.runCommand(command);
	        Log4jLogger.logInfo(output);
	        if(output.contains("not"))
	        {
	            Log4jLogger.logInfo("\nAppium is not installed. Output:" + output);
	            System.exit(0);
	        }
	    }
	    Util.sleep(5000);
	    return port;
	}
}
