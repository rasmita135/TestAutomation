package com.bankbazaar.core;

import org.apache.log4j.Logger;
public class Log4jLogger
{
    private static Logger LOG = Logger.getLogger(Log4jLogger.class);


    public static void logInfo(String message)
    {
        LOG.info(message);
    }

    public static void logError(String message)
    {
        LOG.error(message);
    }

    public static void logError(Object message)
    {
        LOG.error(message);
    }

    public static void logDebug(String message)
    {
        LOG.debug(message);
    }



}
