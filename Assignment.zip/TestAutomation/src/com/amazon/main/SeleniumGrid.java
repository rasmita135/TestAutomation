package com.amazon.main;

import org.openqa.grid.web.Hub;

public class SeleniumGrid {
	 private static Hub hub;

	    public static void StartGrid(String seleniumGridServer)
	    {
	        try {
	            GridHubConfiguration config = new GridHubConfiguration();
	            config.setHost(seleniumGridServer);
	            config.setTimeout(60000000);
	            hub = new Hub(config);
	            hub.start();
	        }
	        catch (Exception e)
	        {
	            Log4jLogger.logError(e);
	            e.printStackTrace();
	        }
	    }

	    public static void StopGrid()
	    {
	        try
	        {
	            hub.stop();
	        }
	        catch (Exception e)
	        {
	            Log4jLogger.logError(e);
	            e.printStackTrace();
	        }
	    }
}
