package com.amazon.main.tool;

import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Appium implements ITool {
	   public AppiumDriver<WebElement> driver = null;
	    public WebDriverWait wait;

	    public Appium(WebDriver driver)
	    {
	        this.driver = (AppiumDriver<WebElement>)driver;
	        this.wait = new WebDriverWait(driver, 10);
	    }

	   

	    public void findelementbyname(WebElement element)
	    {
	     
	        waitAndScrollToElement(element);
	        element.click();
	    }

	    public void findelementbyxpath(String xpath)
	    {
	       
	        WebElement element = getWebElement(xpath);
	        element.click();
	    }
	    private void waitAndScrollToElement(WebElement element) {
	        try{
	            wait.until(ExpectedConditions.elementToBeClickable(element));
	            scrollToElement(element);
	        }
	        catch(Exception e){
	        }
	    }
	   
}
