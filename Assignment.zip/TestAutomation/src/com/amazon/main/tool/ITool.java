package com.amazon.main.tool;

import java.util.List;

import org.openqa.selenium.WebElement;

public interface ITool {
	void findelementbyname(string s);
	void findelementbyxpath(String s);

}
