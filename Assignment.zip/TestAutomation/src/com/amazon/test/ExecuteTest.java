package com.amazon.test;

import java.util.Map;

public class ExecuteTest extends BaseTest {

	    @Factory
	    public ExecuteTest(String deviceId) {
	        this.deviceId = deviceId;
	    }


	    @Test(groups = {""},enabled = true))
	           

	    public void Login to amazon search randomly for TV() {
	        Map<String, String> defaultValues = ResourceValueParser.getAllValues(valuePath);
	        defaultValues.put(Constants.SearchType, "DigitalTv");
	        defaultValues.put(Constants.username, "amazon");
	        pages.AndloginPage().navigateToLoginPage();
	        pages.AndSearchPage.clickOnSearchPage();
	        pages.AndCartPage.SelectCartPage();
	        pases.AndPurchasePage.clickonBuyNow();

	    }

}
