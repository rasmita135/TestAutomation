package com.amazon.test;

public class BaseTest {
	{
	    protected final String defaultValues = "DigitalTv";
	    protected final String valuePath = defaultValues;

	    protected String deviceId;


	    @AfterClass(alwaysRun = true)
	    public void classTearDown()
	    {
	        Driver.quit();
	    }


}
