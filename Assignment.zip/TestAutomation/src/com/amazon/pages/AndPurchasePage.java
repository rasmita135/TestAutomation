package com.amazon.pages;

public class AndPurchasePage {

}
