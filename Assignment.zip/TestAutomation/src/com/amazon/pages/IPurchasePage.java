package com.amazon.pages;

public interface IPurchasePage {
	void purchase ();

}
