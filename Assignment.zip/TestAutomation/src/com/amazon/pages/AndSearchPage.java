package com.amazon.pages;

public class AndSearchPage {

}
