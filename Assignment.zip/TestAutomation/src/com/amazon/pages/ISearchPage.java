package com.amazon.pages;

public interface ISearchPage {
	void search(String data);

}
