package com.amazon.pages;

public interface IloginPage {
	void username(String name);
	void password(String password);
	void login();

}
