package com.amazon.pages;

public interface ICartPage {
	 void click_AddToCart();
	  

}
